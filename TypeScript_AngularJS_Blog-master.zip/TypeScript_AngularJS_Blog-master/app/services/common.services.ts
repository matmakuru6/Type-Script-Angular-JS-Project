namespace moduleFirstDemo.common{
    angular.module('common.services',['ngResource'])
}