var moduleFirstDemo;
(function (moduleFirstDemo) {
    var common;
    (function (common) {
        angular.module('common.services', ['ngResource']);
    })(common = moduleFirstDemo.common || (moduleFirstDemo.common = {}));
})(moduleFirstDemo || (moduleFirstDemo = {}));
//# sourceMappingURL=common.services.js.map