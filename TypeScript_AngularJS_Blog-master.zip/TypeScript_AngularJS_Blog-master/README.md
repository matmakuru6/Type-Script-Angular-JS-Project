# Blog build with Typescript and AngularJS
This is a project built with Typescript and AngularJS v1.4.7 https://blog-typescript.firebaseapp.com/#/
